package com.azarquiel.s2daw.MiPrimeraApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiPrimeraAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiPrimeraAppApplication.class, args);
	}

}
