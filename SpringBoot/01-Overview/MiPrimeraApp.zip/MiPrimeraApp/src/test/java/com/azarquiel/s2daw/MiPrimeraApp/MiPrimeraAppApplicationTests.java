package com.azarquiel.s2daw.MiPrimeraApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiPrimeraAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
