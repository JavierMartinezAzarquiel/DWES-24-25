package azarquiel.s2daw.foster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FosterApplicationTests {

	@Test
	void contextLoads() {
	}

}
