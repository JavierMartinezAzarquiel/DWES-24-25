package com.azarquiel.s2daw.ejemploThymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploThymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemploThymeleafApplication.class, args);
	}

}
